#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    time_t start = clock();

    int i, j, k, m, n, x, y;
    float **a, l, r, t, b;

    FILE *fp, *fin;
    fp = fopen("laplace.dat","w"); //output will be stored in this file
    fin = fopen("input.in", "r");
    
    printf("\tEnter boundary conditions\n");
    fscanf(fin, "%f",&l);
    printf("\tValue on left side: %f", l);
    fscanf(fin, "%f",&r);
    printf("\tValue on right side: %f", r);
    fscanf(fin, "%f",&t);
    printf("\tValue on top side: %f", t);
    fscanf(fin, "%f",&b);
    printf("\tValue on bottom side: %f", b);
    fscanf(fin, "%d",&x);
    printf("\tEnter length in x direction: %d", x);
    fscanf(fin, "%d",&m);
    printf("\tEnter number of steps in x direction: %d", m);
    fscanf(fin, "%d",&y);
    printf("\tEnter length in y direction: %d", y);
    fscanf(fin, "%d",&n);
    printf("\tEnter number of steps in y direction: %d", n);
    m++;
    n++; //number of mesh points is one more than number of steps
    
    a = calloc(m + 1, sizeof(float *));
    for (int i = 0; i < m + 1; i++) {
        a[i] = calloc(n + 1, sizeof(float));
    }
    
    for(i = 1; i <= m; i++) {  //assigning boundary values begins
        a[i][1] = b;
        a[i][n] = t;
    }
    for(i = 1; i <= n; i++) {
        a[1][i] = l;
        a[m][i] = r;
    }                         //assigning boundary values ends
    for(i = 2; i < m; i++) {
        for(j = 2; j < n; j++) {
            a[i][j] = t; //initialization of interior grid points
        }
    }

    for (k = 0; k < 100; k++) {
        for (int diag = 0; diag < m; diag++) {
            for (l = 0; l <= diag; l++) {
                i = diag - l;
                j = l;

                if (i < 2 || j < 2) continue;

                a[i][j] = (a[i - 1][j] + a[i + 1][j] + a[i][j - 1] + a[i][j + 1]) / 4;
            }
        }
        
        for (int diag = m; diag <= 2 * (m - 1); diag++) {
            int nr_iter = 2 * (m - 1) - diag;
            for (l = 0; l <= nr_iter; l++) {
                i = m - 1 - l;
                j = diag - (m - 1) + l;

                if (i < 2 || j < 2) continue;

                a[i][j] = (a[i - 1][j] + a[i + 1][j] + a[i][j - 1] + a[i][j + 1]) / 4;
            }
        }
    }

    for(i = 1; i <= m; i++) {
        for(j = 1; j <= n; j++) {
            fprintf(fp, "%.2f\t", a[i][j]);
        }
        fprintf(fp, "\n");
    }
    fclose(fp);
    for (int i = 0; i < m + 1; i++) {
        free(a[i]);
    } free(a);
    printf("\nData stored\nPress any key to exit...");

    time_t end = clock();

    printf("Total time: %f\n", ((double)(end - start)  / CLOCKS_PER_SEC));


    return 0;
}