# Laplace Equation Solver

## Week 1 (9 nov - 16 nov)
- Choosing the subject for the project -> Laplace Equation

## Week 2 (16 nov - 23 nov)
- Searching a good sequential version of the algorithm. End up using the one here: http://numericalcomputation.blogspot.com/2012/06/c-code-to-solve-laplaces-equation-by.html
- Rewriting the algorithm so that it receives input from a text file named "input.in",
containing the initial values on the left/right/top/bottom side of the matrix,
the size of the matrix and the number of steps.

## Week 3 (23 nov - 30 nov)
- Tested the sequential implementation on various inputs to get an idea about the
computation time.
- Refactored the code to be able to run the program without any interaction with the
user. Replaced static memory allocation with dynamic memory allocation.
- Visualized the results using Origin to plot the .dat file.
- Added a simple Makefile with build, run and clean rules.

## Week 4 (30 nov - 7 dec)
- Refactored the code so that it allows parallelisation. The initial version traversed
the matrix in regular order with i -> 2:m and j -> 2:m, and for each element it computed
the arithmetic mean of its neighbors. Since each element is dependent on 2 elements situated
in different rows and 2 elements situated in different columns, it was impossible to
parallelise the program by splitting the rows/columns to the threads. As a result, we
ended up traversing using the secondary diagonals, as shown in the picture below:
- ![Algorithm1](./profiling/algorithm.jpeg)

- For the first step, we traversed the upper diagonals and shared the elements from a
diagonal to the threads. Afterwards we traverse the matrix using the lower diagonals
(the ones in blue) in the same manner:
- ![Algorithm2](./profiling/algorithm2.jpg)

- We also tried multiple workarounds or heuristics:
We considered traversing the matrix in the following manner, thus reducing
a m * n matrix to a (m - i) (n - i) submatrix at each i step, but the solution
wasn't good for parallelisation as it did not allow us to effectively split
the border:
- ![Algorithm3](./profiling/algorithm3.jpg)

- Since we keeped the diagonal implementation, we had to add a barrier after every
diagonal. This equals 2 * m - 1 barriers, so 2 * m - 1 syscalls, which take a lot
of time for large values of m. To optimise this, we thought of adding a heuristic
in order to only split the largest diagonals (so that the barrier_wait calls are
worth it) and run the sequential implementation for small diagonals. We chose
to stay with the full parallel implementation in order to better analyse the results.

- With that in mind, by the end of this week we finished the Pthreads and OpenMP implementation.

## Week 5 (7 dec - 14 dec)

- We started developing the MPI version of this algorithm, which was the most difficult
because we had to rethink the flow of the program a bit. To ensure that each process
has the most recent matrix, we added a broadcast for each diagonal, which slows down
the execution time greatly for large values of m. Since each process operates only
on a fraction of a diagonal, by the end of each step we must assemble these fractions
to that by the start of the next step, each process has the full matrix. To do that
the process with rank 0 was designated as master. He is the one that computes its
part of the diagonal, then using MPI_Recv calls, receives an array from each other
process. The master then copies the arrays received into the matrix diagonal.

- To ensure that the algorithm is correct regardless of the implementation (OpenMP/
Pthreads/MPI) and the number of threads (or processes), we added a checker.sh file
that automatically verifies this for us.

## Week 6 (14 dec - 21 dec)

- Checking the speedup of the implementation.

For a specific input, found on gitlab, we have obtained the following results:
```
Seq
74.626603

MPI
205.654015 - 2 processes
298.118364 - 4 processes
384.021120 - 6 processes

Pthread
93.905943 -  2 threads
136.127107 - 4 threads
175.352110 - 6 threads

Openmp
43.305055 - 2 threads
47.376678 - 4 threads
258.692909 - 6 threads
```
After running the implementation on a processor with 4 cores, giving for each
implementation 2, 4 and respectively 6 threads/proccessors (for MPI), we concluded
that, considering the data dependencies and the synchronization, the openmp variant
is the fastest of all 3 of them (4, if we include also the sequential one). The
time taken on pthreads and MPI can be caused because of the synchronization elements
(barrier was the most used for pthreads, for example) and others processes launched
in the same time (that were consuming processor cycles). MPI is the worst, since
each element has to be sent to the other process, since there appears a huge overhead
caused by sending and receiving lots of data.

- The same conclusions results also from vtune analysis.

- The MPI implementation had many bugs, so during this week we also took our time
to solve them.

- Profiling the implementations using cachegrind. The generated files after using this
tool can be found in profiling/<implementation_type>


## Team:
- Cazan Bogdan-Marian
- Oprea-Groza Gabriel
- Smau Mara-Alexandra
