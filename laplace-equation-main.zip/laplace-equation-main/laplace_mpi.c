#include "mpi.h"
#include <stdio.h>
#include <stdlib.h>

#define MASTER 0
#define K_LIMIT 100

int min(int a, int b) {
    return a < b ? a : b;
}

int main (int argc, char *argv[]) {
    int rank, len;

    int i, j, k, m, n, x, y;
    float **a, l, r, t, b;
    float* partial_res = calloc(1000, sizeof(float));
    
    int no_proc;
    MPI_Init(&argc, &argv);
    double start = MPI_Wtime();
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &no_proc);

    if (rank == MASTER) {
        FILE *fp, *fin;
        fin = fopen("input.in", "r");
        
        //Enter boundary conditions:

        //Value on left side:
        fscanf(fin, "%f",&l);
        //Value on right side:
        fscanf(fin, "%f",&r);
        //Value on top side:
        fscanf(fin, "%f",&t);
        //Value on bottom side:
        fscanf(fin, "%f",&b);
        //Enter length in x direction:
        fscanf(fin, "%d",&x);
        //Enter number of steps in x direction:
        fscanf(fin, "%d",&m);
        //Enter length in y direction:
        fscanf(fin, "%d",&y);
        //Enter number of steps in y
        fscanf(fin, "%d",&n);

        m++;
        n++; //number of mesh points is one more than number of steps
        
        a = calloc(m + 1, sizeof(float *));
        for (int i = 0; i < m + 1; i++) {
            a[i] = calloc(n + 1, sizeof(float));
        }
        
        for(i = 1; i <= m; i++) {  //assigning boundary values begins
            a[i][1] = b;
            a[i][n] = t;
        }
        for(i = 1; i <= n; i++) {
            a[1][i] = l;
            a[m][i] = r;
        }                         //assigning boundary values ends
        for(i = 2; i < m; i++) {
            for(j = 2; j < n; j++) {
                a[i][j] = t; //initialization of interior grid points
            }
        }

        MPI_Bcast(&m, 1, MPI_INT, MASTER, MPI_COMM_WORLD);
        MPI_Bcast(&n, 1, MPI_INT, MASTER, MPI_COMM_WORLD);

        for (k = 0; k < K_LIMIT; k++) {
            int start, end, limit;

            for (int diag = 4; diag < m; diag++) {

                for (int i = 0; i < m + 1; i++) {
                    MPI_Bcast(a[i], n + 1, MPI_FLOAT, MASTER, MPI_COMM_WORLD);
                }
                
                limit = diag + 1;
                start = rank * (double)limit / no_proc;
                end = min((rank + 1) * (double)limit / no_proc, limit);

                for (l = start; l < end; l++) {
                    i = diag - l;
                    j = l;

                    if (i < 2 || j < 2) continue;

                    a[i][j] = (a[i - 1][j] + a[i + 1][j] + a[i][j - 1] + a[i][j + 1]) / 4;
             
                }

                for (int crt_proc = 1; crt_proc < no_proc; crt_proc++) {

                    start = crt_proc * (double)limit / no_proc;
                    end = min((crt_proc + 1) * (double)limit / no_proc, limit);

                    int prev_l = l;
                    int partial_size;

                    MPI_Recv(&partial_size, 1, MPI_INT, crt_proc, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                    MPI_Recv(partial_res, partial_size, MPI_FLOAT, crt_proc, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

                    for (int cnt = 0; cnt < partial_size; cnt ++) {
                        i = diag - l;
                        j = l;
                        l++;

                        a[i][j] = partial_res[cnt];
                    }

                    l = prev_l + end - start;
                }
            }

            for (int diag = m; diag <= 2 * (m - 1); diag++) {
                for (int i = 0; i < m + 1; i++) {
                    MPI_Bcast(a[i], n + 1, MPI_FLOAT, MASTER, MPI_COMM_WORLD);
                }
                int nr_iter = 2 * (m - 1) - diag;
                
                limit = nr_iter + 1;
                start = rank * (double)limit / no_proc;
                end = min((rank + 1) * (double)limit / no_proc, limit);

                for (l = start; l < end; l++) {
                    i = m - 1 - l;
                    j = diag - (m - 1) + l;

                    if (i < 2 || j < 2) continue;

                    a[i][j] = (a[i - 1][j] + a[i + 1][j] + a[i][j - 1] + a[i][j + 1]) / 4;
                }

                for (int crt_proc = 1; crt_proc < no_proc; crt_proc++) {
                    int partial_size;

                    start = crt_proc * (double)limit / no_proc;
                    end = min((crt_proc + 1) * (double)limit / no_proc, limit);
                    int prev_l = l;

                    MPI_Recv(&partial_size, 1, MPI_INT, crt_proc, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                    MPI_Recv(partial_res, partial_size, MPI_FLOAT, crt_proc, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

                    for (int cnt = 0; cnt < partial_size; cnt ++) {
                        i = m - 1 - l;
                        j = diag - (m - 1) + l;
                        l++;

                        a[i][j] = partial_res[cnt];
                    }

                    l = prev_l + end - start;
                }
            }
        }

        fp = fopen("laplace.dat_mpi","w"); //output will be stored in this file
        for(i = 1; i <= m; i++) {
            for(j = 1; j <= n; j++) {
                fprintf(fp, "%.2f\t", a[i][j]);
            }
            fprintf(fp, "\n");
        }
        fclose(fp);

    }

    else {

        MPI_Bcast(&m, 1, MPI_INT, MASTER, MPI_COMM_WORLD);
        MPI_Bcast(&n, 1, MPI_INT, MASTER, MPI_COMM_WORLD);
        
        a = calloc(m + 1, sizeof(float *));
        for (int i = 0; i < m + 1; i++) {
            a[i] = calloc(n + 1, sizeof(float));
        }

        for (k = 0; k < K_LIMIT; k++) {

            int start, end, limit;

            for (int diag = 4; diag < m; diag++) {
                //broadcast_matrix(a, m, n);
                for (int i = 0; i < m + 1; i++) {
                    MPI_Bcast(a[i], n + 1, MPI_FLOAT, MASTER, MPI_COMM_WORLD);
                }

                limit = diag + 1;
                start = rank * (double)limit / no_proc;
                end = min((rank + 1) * (double)limit / no_proc, limit);
                
                int dim = end - start;
                int cnt = 0;

                for (l = start; l < end; l++) {
                    i = diag - l;
                    j = l;

                    if (i < 2 || j < 2) {
                        partial_res[cnt++] = a[i][j];
                    }
                    else {
                        partial_res[cnt++] = (a[i - 1][j] + a[i + 1][j] + a[i][j - 1] + a[i][j + 1]) / 4;
                    }
                }
                MPI_Send(&cnt, 1, MPI_INT, MASTER, 0, MPI_COMM_WORLD);
                MPI_Send(partial_res, cnt, MPI_FLOAT, MASTER, 0, MPI_COMM_WORLD);
                
            }

            for (int diag = m; diag <= 2 * (m - 1); diag++) {
                for (int i = 0; i < m + 1; i++) {
                    MPI_Bcast(a[i], n + 1, MPI_FLOAT, MASTER, MPI_COMM_WORLD);
                }

                int nr_iter = 2 * (m - 1) - diag;

                limit = nr_iter + 1;
                start = rank * (double)limit / no_proc;
                end = min((rank + 1) * (double)limit / no_proc, limit);

                int dim = end - start;
                int cnt = 0;

                for (l = start; l < end; l++) {
                    i = m - 1 - l;
                    j = diag - (m - 1) + l;

                    if (i < 2 || j < 2) {
                        partial_res[cnt++] = a[i][j];
                    }
                    else {
                        partial_res[cnt++] = (a[i - 1][j] + a[i + 1][j] + a[i][j - 1] + a[i][j + 1]) / 4;
                    }
                }

                MPI_Send(&cnt, 1, MPI_INT, MASTER, 0, MPI_COMM_WORLD);
                MPI_Send(partial_res, cnt, MPI_FLOAT, MASTER, 0, MPI_COMM_WORLD);
            }
        }
    }


    free(partial_res);
    if (rank == MASTER) {
        double end = MPI_Wtime();
        printf("Total time: %f\n", ((double)(end - start)));
    }

    MPI_Finalize();
}