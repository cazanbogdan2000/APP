#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define THREAD_NO 4
int k, m, n, x, y;
float **a, l, r, t, b;
pthread_barrier_t barrier;

int min(int a, int b) {
    return a < b ? a : b;
}


void *thread_func(void *arg) {
    int id = *(int*) arg;
    int contor = 0;
    int start;
    int end;
    int i, j;
    int cnt;

    for (contor = 0; contor < 100; contor++) {

        for (int diag = 0; diag < m; diag++) {

            int limit = diag + 1;

            pthread_barrier_wait(&barrier);
            start = id * (double)limit / THREAD_NO;
            end = min((id + 1) * (double)limit / THREAD_NO, limit);

            for (cnt = start; cnt < end; cnt++) {
                i = diag - cnt;
                j = cnt;

                if (i < 2 || j < 2) continue;
                    a[i][j] = (a[i - 1][j] + a[i + 1][j] + a[i][j - 1] + a[i][j + 1]) / 4;

            }
        }
            
        
        for (int diag = m; diag <= 2 * (m - 1); diag++) {

            int nr_iter = 2 * (m - 1) - diag;
            int limit = nr_iter + 1;


            pthread_barrier_wait(&barrier);
            start = id * (double)limit / THREAD_NO;
            end = min((id + 1) * (double)limit / THREAD_NO, limit);

            for (cnt = start; cnt < end; cnt++) {
                i = m - 1 - cnt;
                j = diag - (m - 1) + cnt;

                if (i < 2 || j < 2) continue;
                
                a[i][j] = (a[i - 1][j] + a[i + 1][j] + a[i][j - 1] + a[i][j + 1]) / 4;
            }
        }
    }
}

int main() {
    time_t start = clock();

    int i, j;
    FILE *fp, *fin;
    fp = fopen("laplace.dat_pthreads","w"); //output will be stored in this file
    fin = fopen("input.in", "r");
    
    //Enter boundary conditions:

    //Value on left side:
    fscanf(fin, "%f",&l);
    //Value on right side:
    fscanf(fin, "%f",&r);
    //Value on top side:
    fscanf(fin, "%f",&t);
    //Value on bottom side:
    fscanf(fin, "%f",&b);
    //Enter length in x direction:
    fscanf(fin, "%d",&x);
    //Enter number of steps in x direction:
    fscanf(fin, "%d",&m);
    //Enter length in y direction:
    fscanf(fin, "%d",&y);
    //Enter number of steps in y
    fscanf(fin, "%d",&n);
    m++;
    n++; //number of mesh points is one more than number of steps
    
    a = calloc(m + 1, sizeof(float *));
    for (int i = 0; i < m + 1; i++) {
        a[i] = calloc(n + 1, sizeof(float));
    }
    
    for(i = 1; i <= m; i++) {  //assigning boundary values begins
        a[i][1] = b;
        a[i][n] = t;
    }
    for(i = 1; i <= n; i++) {
        a[1][i] = l;
        a[m][i] = r;
    }                         //assigning boundary values ends
    for(i = 2; i < m; i++) {
        for(j = 2; j < n; j++) {
            a[i][j] = t; //initialization of interior grid points
        }
    }

    pthread_barrier_init(&barrier, NULL, THREAD_NO);
    pthread_t *threads;
    threads = (pthread_t*) malloc(THREAD_NO * sizeof(pthread_t));
    int *thread_ids = calloc(THREAD_NO, sizeof(int));
    void *status;
    int ret;

    for (int i = 0; i < THREAD_NO; i++) {

        thread_ids[i] = i;

        ret = pthread_create(&threads[i], NULL, thread_func, &thread_ids[i]);
        if (ret) {
            exit(-1);
        }
    }


    for (int i = 0; i < THREAD_NO; i++) {
        ret = pthread_join(threads[i], &status);
        if (ret) {
            exit(-1);
        }
    }

    for(i = 1; i <= m; i++) {
        for(j = 1; j <= n; j++) {
            fprintf(fp, "%.2f\t", a[i][j]);
        }
        fprintf(fp, "\n");
    }
    fclose(fp);

    time_t end = clock();

    printf("Total time: %f\n", ((double)(end - start)  / CLOCKS_PER_SEC));
  
    return 0;
}
