#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

int main(int argc, char* argv[]) {
    double start = omp_get_wtime();

    omp_set_num_threads(4);
    if (argc > 1) {
        omp_set_num_threads(atoi(argv[1]));
    }

    int i, j, k, m, n, x, y;
    float **a, r, t, b, l;

    FILE *fp, *fin;
    fp = fopen("laplace.dat_openmp","w"); //output will be stored in this file
    fin = fopen("input.in", "r");
    
    printf("\tEnter boundary conditions\n");
    fscanf(fin, "%f",&l);
    printf("\tValue on left side: %f", l);
    fscanf(fin, "%f",&r);
    printf("\tValue on right side: %f", r);
    fscanf(fin, "%f",&t);
    printf("\tValue on top side: %f", t);
    fscanf(fin, "%f",&b);
    printf("\tValue on bottom side: %f", b);
    fscanf(fin, "%d",&x);
    printf("\tEnter length in x direction: %d", x);
    fscanf(fin, "%d",&m);
    printf("\tEnter number of steps in x direction: %d", m);
    fscanf(fin, "%d",&y);
    printf("\tEnter length in y direction: %d", y);
    fscanf(fin, "%d",&n);
    printf("\tEnter number of steps in y direction: %d", n);
    m++;
    n++; //number of mesh points is one more than number of steps
    
    a = calloc(m + 1, sizeof(float *));
    for (int i = 0; i < m + 1; i++) {
        a[i] = calloc(n + 1, sizeof(float));
    }
    
    for(i = 1; i <= m; i++) {  //assigning boundary values begins
        a[i][1] = b;
        a[i][n] = t;
    }
    for(i = 1; i <= n; i++) {
        a[1][i] = l;
        a[m][i] = r;
    }                         //assigning boundary values ends
    for(i = 2; i < m; i++) {
        for(j = 2; j < n; j++) {
            a[i][j] = t; //initialization of interior grid points
        }
    }
     
    for (k = 0; k < 100; k++) {
        for (int diag = 0; diag < m; diag++) {\

            #pragma omp parallel for private(i, j)
            for (int q = 0; q <= diag; q++) {
                i = diag - q;
                j = q;

                if (i < 2 || j < 2) continue;

                a[i][j] = (a[i - 1][j] + a[i + 1][j] + a[i][j - 1] + a[i][j + 1]) / 4;
            }
        }
        
        for (int diag = m; diag <= 2 * (m - 1); diag++) {
            int nr_iter = 2 * (m - 1) - diag;
            #pragma omp parallel for private(i, j)
            for (int q = 0; q <= nr_iter; q++) {
                i = m - 1 - q;
                j = diag - (m - 1) + q;

                if (i < 2 || j < 2) continue;

                a[i][j] = (a[i - 1][j] + a[i + 1][j] + a[i][j - 1] + a[i][j + 1]) / 4;
            }
        }
    }


    for(i = 1; i <= m; i++) {
        for(j = 1; j <= n; j++) {
            fprintf(fp, "%.2f\t", a[i][j]);
        }
        fprintf(fp, "\n");
    }

    fclose(fp);
    for (int i = 0; i < m + 1; i++) {
        free(a[i]);
    } free(a);
    printf("\nData stored\nPress any key to exit...\n\n");


    double end = omp_get_wtime();

    printf("Total time: %f\n", end - start);

    return 0;
}
