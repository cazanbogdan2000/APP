#/bin/bash

make clean >/dev/null 
make >/dev/null 
valid=1
for i in $(seq 1 5)
do
	 make run_seq >/dev/null 
	 make run_openmp > /dev/null 
	 make run_pthreads >/dev/null 
	 make run_mpi >/dev/null 

	 diff laplace.dat laplace.dat_pthreads >/dev/null 
	 error=$?
	 if [ $error -eq 1 ]
	 then
	 	valid=0
	 	echo "Pthreads is different"
	 fi

	 diff laplace.dat laplace.dat_openmp >/dev/null 
	 error=$?
	 if [ $error -eq 1 ]
	 then
	 	valid=0
	 	echo "OpenMP is different"
	 fi

	 diff laplace.dat laplace.dat_mpi >/dev/null 
	 error=$?
	 if [ $error -eq 1 ]
	 then
	 	valid=0
	 	echo "MPI is different"
	 fi

done;

if [ $valid -eq 1 ]
then
	echo "Good work"
else
	echo "That's bad"
fi

make clean >/dev/null
rm *.dat*